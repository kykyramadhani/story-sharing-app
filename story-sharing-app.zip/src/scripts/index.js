import 'leaflet/dist/leaflet.css';
import '../styles/styles.css';
import App from './pages/app';

document.addEventListener('DOMContentLoaded', async () => {
  const app = new App({
    content: document.querySelector('#main-content'),
    drawerButton: document.querySelector('#drawer-button'),
    navigationDrawer: document.querySelector('#navigation-drawer'),
  });

  const authLink = document.getElementById('auth-link');
  if (!authLink) {
    console.error('Auth link element not found');
  } else {
    if (localStorage.getItem('token')) {
      authLink.textContent = 'Logout';
      authLink.href = '#/logout';
      authLink.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('token');
        window.location.hash = '#/login';
      });
    } else {
      authLink.textContent = 'Login';
      authLink.href = '#/login';
    }
  }

  if (!localStorage.getItem('token') && !window.location.hash) {
    window.location.hash = '#/login';
  }

  await app.renderPage();

  window.addEventListener('hashchange', async () => {
    // Update auth link on hash change
    if (localStorage.getItem('token')) {
      authLink.textContent = 'Logout';
      authLink.href = '#/logout';
    } else {
      authLink.textContent = 'Login';
      authLink.href = '#/login';
    }
    await app.renderPage();
  });
});