const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  MAPTILER_API_KEY: 'dnGNj2cMGx7mrqsqSUit', 
};

export default CONFIG;